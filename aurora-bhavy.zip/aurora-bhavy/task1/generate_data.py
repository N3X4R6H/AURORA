
import random
import csv
from pathlib import Path

random.seed(42)

# 1. Define words related to our toy language
subjects = [
    "machine learning",
    "neural networks",
    "artificial intelligence",
    "language models",
    "deep learning",
]

verbs = [
    "learns patterns from",
    "predicts values from",
    "analyzes information from",
    "extracts features from",
    "discovers relationships in",
]

objects = [
    "training data",
    "scientific observations",
    "numerical sequences",
    "text data",
    "historical records",
]

endings = [
    "to improve prediction",
    "for better accuracy",
    "during model training",
    "to understand patterns",
    "for scientific research",
]

# 2. Generate synthetic sentences
sentences = []

for _ in range(1000):
    subject = random.choice(subjects)
    verb = random.choice(verbs)
    obj = random.choice(objects)
    ending = random.choice(endings)

    sentence = f"{subject} {verb} {obj} {ending}."
    sentences.append(sentence)

# 3. Save the dataset
output_path = Path("data/synthetic_text.csv")
output_path.parent.mkdir(parents=True, exist_ok=True)

with output_path.open("w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["text"])

    for sentence in sentences:
        writer.writerow([sentence])

print(f"Generated {len(sentences)} synthetic sentences.")
print(f"Saved dataset to: {output_path.resolve()}")

print("\nFirst 5 examples:")
for sentence in sentences[:5]:
    print("-", sentence)
