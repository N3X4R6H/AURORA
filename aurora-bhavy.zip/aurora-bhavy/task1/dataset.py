
import torch
from torch.utils.data import Dataset, DataLoader
from prepare_data import (
    encoded_sentences,
    token_to_id,
)

# Configuration
batch_size = 4

class SyntheticTextDataset(Dataset):
    def __init__(self, encoded_sentences):
        self.samples = []

        for token_ids in encoded_sentences:
            if len(token_ids) >= 2:
                self.samples.append(
                    (
                        token_ids[:-1],
                        token_ids[1:]
                    )
                )

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        inputs, targets = self.samples[index]

        return (
            torch.tensor(inputs, dtype=torch.long),
            torch.tensor(targets, dtype=torch.long)
        )


# Create dataset and dataloader
dataset = SyntheticTextDataset(encoded_sentences)

dataloader = DataLoader(
    dataset,
    batch_size=batch_size,
    shuffle=True
)

# Inspect one batch
inputs, targets = next(iter(dataloader))

print("Dataset size:", len(dataset))
print("Vocabulary size:", len(token_to_id))
print("Batch size:", batch_size)

print("\nInput tensor shape:", inputs.shape)
print("Target tensor shape:", targets.shape)

print("\nInput batch:")
print(inputs)

print("\nTarget batch:")
print(targets)

assert inputs.shape == targets.shape
assert inputs.dtype == torch.long
assert targets.dtype == torch.long

print("\nPyTorch batch creation: PASS")
