
import csv
import re
from pathlib import Path

# 1. Locate and load the CSV file
data_path = Path(__file__).parent / "data" / "synthetic_text.csv"

sentences = []

with data_path.open("r", encoding="utf-8", newline="") as file:
    reader = csv.DictReader(file)

    for row in reader:
        sentences.append(row["text"].lower())

print("Number of sentences:", len(sentences))

# 2. Tokenize the sentences
def tokenize(text):
    return re.findall(r"\b\w+\b|[^\w\s]", text)

tokenized_sentences = [tokenize(sentence) for sentence in sentences]

print("\nExample sentence:")
print(sentences[0])

print("\nTokens:")
print(tokenized_sentences[0])

# 3. Build the vocabulary
special_tokens = ["<PAD>", "<UNK>"]

all_tokens = set()

for tokens in tokenized_sentences:
    all_tokens.update(tokens)

vocabulary = special_tokens + sorted(all_tokens)

token_to_id = {
    token: index
    for index, token in enumerate(vocabulary)
}

id_to_token = {
    index: token
    for token, index in token_to_id.items()
}

print("\nVocabulary size:", len(vocabulary))
print("\nFirst 20 vocabulary entries:")
print(vocabulary[:20])

# 4. Convert sentences into numerical IDs
encoded_sentences = [
    [token_to_id[token] for token in tokens]
    for tokens in tokenized_sentences
]

print("\nEncoded sentence:")
print(encoded_sentences[0])

# 5. Verify encoding and decoding
decoded_sentence = " ".join(
    id_to_token[token_id]
    for token_id in encoded_sentences[0]
)

print("\nDecoded tokens:")
print(decoded_sentence)

assert len(encoded_sentences) == len(sentences)
assert all(
    token in token_to_id
    for tokens in tokenized_sentences
    for token in tokens
)

print("\nDataset loading and tokenization: PASS")




# 6. Create input-target sequences for next-token prediction

input_sequences = []
target_sequences = []

for token_ids in encoded_sentences:
    # Need at least two tokens to predict the next token
    if len(token_ids) < 2:
        continue

    inputs = token_ids[:-1]
    targets = token_ids[1:]

    input_sequences.append(inputs)
    target_sequences.append(targets)

print("\nNumber of training sequences:", len(input_sequences))

# Inspect the first sequence
print("\nFirst input sequence:")
print(input_sequences[0])

print("\nFirst target sequence:")
print(target_sequences[0])

# Verify next-token alignment
first_tokens = tokenized_sentences[0]

print("\nInput tokens:")
print(first_tokens[:-1])

print("\nTarget tokens:")
print(first_tokens[1:])

assert len(input_sequences) == len(target_sequences)

for inputs, targets in zip(input_sequences, target_sequences):
    assert len(inputs) == len(targets)
    assert inputs[1:] == targets[:-1]

print("\nInput-target sequence creation: PASS")
